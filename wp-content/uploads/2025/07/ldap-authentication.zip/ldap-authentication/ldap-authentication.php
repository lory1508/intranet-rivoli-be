<?php
/**
 * Plugin Name: LDAP Authentication
 * Description: Authenticate WordPress users via Microsoft Active Directory and sync user data.
 * Version: 1.0.1
 * Author: Lorenzo Galassi
 */

define('LG_LDAP_AUTH_PLUGIN_DIR', plugin_dir_path(__FILE__));

if (is_admin()) {
    require_once LG_LDAP_AUTH_PLUGIN_DIR . 'admin/settings-page.php';
}

function lg_ldap_authenticate($username, $password) {
    $options = get_option('lg_ldap_auth_settings');
    $server = $options['ldap_host'] ?? '';
    $port = $options['ldap_port'] ?? 389;
    $bind_dn = $options['ldap_bind_user'] ?? '';
    $bind_password = $options['ldap_bind_pass'] ?? '';
    $base_dn = $options['ldap_base_dn'] ?? '';
    $search_filter = $options['ldap_search_filter'] ?? '(sAMAccountName=%s)';
    $user_suffix = $options['ldap_user_suffix'] ?? '';

    if (!$server || !$base_dn) {
        return new WP_Error('ldap_config_error', 'LDAP server or Base DN is not configured.');
    }

    $conn = ldap_connect($server, (int)$port);
    if (!$conn) {
        return new WP_Error('ldap_connection_failed', 'Could not connect to LDAP server.');
    }

    ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);

    if ($bind_dn && $bind_password) {
        $bind = @ldap_bind($conn, $bind_dn, $bind_password);
        if (!$bind) {
            ldap_unbind($conn);
            return new WP_Error('ldap_bind_failed', 'Failed to bind to LDAP with service account.');
        }
    } else {
        $bind = @ldap_bind($conn);
        if (!$bind) {
            ldap_unbind($conn);
            return new WP_Error('ldap_bind_failed', 'Failed anonymous bind to LDAP.');
        }
    }

    $filter = sprintf($search_filter, ldap_escape($username, '', LDAP_ESCAPE_FILTER));
    $search = ldap_search($conn, $base_dn, $filter);
    if (!$search) {
        ldap_unbind($conn);
        return new WP_Error('ldap_search_failed', 'LDAP search failed.');
    }

    $entries = ldap_get_entries($conn, $search);
    if ($entries['count'] == 0) {
        ldap_unbind($conn);
        return new WP_Error('ldap_user_not_found', 'User not found in LDAP.');
    }

    $user_dn = $entries[0]['dn'];
    error_log("[LDAP AUTH] Trying LDAP bind as DN: $user_dn$user_suffix");

    $user_bind = @ldap_bind($conn, $user_dn . $user_suffix, $password);
    if (!$user_bind) {
        $error = ldap_error($conn);
        error_log("[LDAP AUTH] LDAP bind failed for DN $user_dn$user_suffix: $error");
        ldap_unbind($conn);
        return new WP_Error('ldap_auth_failed', "Invalid username or password. Tried DN: $user_dn$user_suffix — Error: $error");
    }

    ldap_unbind($conn);
    return true;
}

add_filter('authenticate', 'lg_ldap_auth_hook', 30, 3);
function lg_ldap_auth_hook($user, $username, $password) {
    if (empty($username) || empty($password)) return $user;

    $username = strstr($username, '@', true) ?: $username;
    error_log("[LDAP AUTH] Login attempt username: $username");

    $blocked_accounts = ['krbtgt', 'guest', 'administrator'];
    if (in_array(strtolower($username), $blocked_accounts)) {
        return new WP_Error('[jwt_auth] ldap_error', '❌ Cannot login as internal system user.');
    }

    $auth_result = lg_ldap_authenticate($username, $password);

    if (is_wp_error($auth_result)) {
        return new WP_Error('[jwt_auth] ldap_error', '❌ LDAP Error...: ' . $auth_result->get_error_message());
    }

    $wp_user = get_user_by('login', $username);
    if (!$wp_user) {
        $user_id = wp_create_user($username, wp_generate_password(), $username . '@example.com');
        if (!is_wp_error($user_id)) {
            $wp_user = get_user_by('id', $user_id);
        } else {
            return new WP_Error('[jwt_auth] ldap_error', '❌ Failed to create WordPress user.');
        }
    }

    return $wp_user;
}

add_action('wp_ajax_lg_ldap_test_connection', function () {
    $options = get_option('lg_ldap_auth_settings');
    $conn = @ldap_connect($options['ldap_host'] ?? '', (int)($options['ldap_port'] ?? 389));
    if (!$conn) {
        echo '❌ Could not connect to LDAP server.';
        wp_die();
    }

    ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);

    if (@ldap_bind($conn, $options['ldap_bind_user'] ?? '', $options['ldap_bind_pass'] ?? '')) {
        echo '✅ Successfully connected and authenticated!';
    } else {
        echo '❌ Bind failed. Check service account credentials.';
    }

    ldap_unbind($conn);
    wp_die();
});
